#!/usr/bin/env bash

if [ $# -eq 0 ]
then
  echo
  echo  Usage: $0 "<name for database (must be 8 characters long or less) > <instance_name>"
  echo
  exit 1
fi
arg1=$1
len=${#arg1}
if [ $len -gt 8 ]
then
  echo
  echo Invalid DB name "$arg1" : Must be 8 characters or less.
  echo DB creation would fail.  Exiting...
  echo
  exit 1
fi

dbname=$1
dbuser=$2
dbpath=$3
dbtuning=$4
dbstopaths=$3


echo "*** Creating DB named: $dbname ***"

# if optional storage paths are not specified
#  db2 create database ${dbname} automatic storage yes on ${dbstopaths} dbpath on ${dbpath} using codeset UTF-8 territory US pagesize 32 K
# Let ootb Db2 container setup take over
db2 create database "${dbname}" automatic storage yes using codeset UTF-8 territory US pagesize 32 K

db2 connect to "${dbname}"


echo "*** Create bufferpool ***"

db2 create bufferpool "${dbname}"_1_32K immediate size 1024 pagesize 32k
db2 create bufferpool "${dbname}"_2_32K immediate size 1024 pagesize 32k
db2 create bufferpool "${dbname}"_3_32K immediate size 1024 pagesize 32k
db2 create bufferpool "${dbname}"_4_32K immediate size 1024 pagesize 32k
db2 create bufferpool "${dbname}"_5_32K immediate size 1024 pagesize 32k
echo "*** Create table spaces ***"
db2 CREATE REGULAR TABLESPACE OSDATA_TS PAGESIZE 32 K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL "${dbname}"_1_32K
db2 CREATE REGULAR TABLESPACE VWDATA_TS PAGESIZE 32 K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL "${dbname}"_2_32K
db2 CREATE REGULAR TABLESPACE VWINDEX_TS PAGESIZE 32 K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL "${dbname}"_3_32K
db2 CREATE REGULAR TABLESPACE VWBLOB_TS PAGESIZE 32 K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL "${dbname}"_4_32K

db2 CREATE USER TEMPORARY TABLESPACE "${dbname}"_TMP_TBS PAGESIZE 32 K MANAGED BY AUTOMATIC STORAGE BUFFERPOOL "${dbname}"_5_32K

echo "*** Grant permissions to DB user ***"
db2 GRANT CREATETAB,CONNECT ON DATABASE  TO user "${dbuser}"
db2 GRANT USE OF TABLESPACE OSDATA_TS TO user "${dbuser}"
db2 GRANT USE OF TABLESPACE VWDATA_TS TO user "${dbuser}"
db2 GRANT USE OF TABLESPACE VWINDEX_TS TO user "${dbuser}"
db2 GRANT USE OF TABLESPACE VWBLOB_TS TO user "${dbuser}"
db2 GRANT USE OF TABLESPACE "${dbname}"_TMP_TBS TO user "${dbuser}"
db2 GRANT SELECT ON SYSIBM.SYSVERSIONS to user "${dbuser}"
db2 GRANT SELECT ON SYSCAT.DATATYPES to user "${dbuser}"
db2 GRANT SELECT ON SYSCAT.INDEXES to user "${dbuser}"
db2 GRANT SELECT ON SYSIBM.SYSDUMMY1 to user "${dbuser}"
db2 GRANT USAGE ON WORKLOAD SYSDEFAULTUSERWORKLOAD to user "${dbuser}"
db2 GRANT IMPLICIT_SCHEMA ON DATABASE to user "${dbuser}"


echo "*** Apply DB tunings ***"
db2 update db cfg for "${dbname}" using LOCKTIMEOUT 30
db2 update db cfg for "${dbname}" using APPLHEAPSZ 2560
db2set DB2_WORKLOAD=FILENET_CM
db2set DB2_MINIMIZE_LISTPREFETCH=YES

# Let Db2 ootb container settings stay
#db2 update db cfg for ${dbname} using LOGBUFSZ 212
#db2 update db cfg for ${dbname} using LOGFILSIZ 6000
# db2 update db cfg for ${dbname} using LOGPRIMARY 10

db2 connect reset

echo "*** Done creating and tuning DB named: ${dbname} ***"
